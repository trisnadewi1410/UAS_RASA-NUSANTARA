class Recipe {
  final int? id;
  final String title;
  final String description;
  final String ingredients;
  final String steps;
  final String? imagePath;
  final int? userId;
  final String? location;

  Recipe({
    this.id,
    required this.title,
    required this.description,
    required this.ingredients,
    required this.steps,
    this.imagePath,
    required this.userId,
    this.location,
  });

  factory Recipe.fromMap(Map<String, dynamic> map) {
    return Recipe(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      ingredients: map['ingredients'],
      steps: map['steps'],
      imagePath: map['imagePath'],
      userId: map['userId'],
      location: map['location'],
    );
  }

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'title': title,
      'description': description,
      'ingredients': ingredients,
      'steps': steps,
      'imagePath': imagePath,
      'userId': userId,
      'location': location,
    };
    if (id != null) {
      map['id'] = id;
    }
    return map;
  }
}
