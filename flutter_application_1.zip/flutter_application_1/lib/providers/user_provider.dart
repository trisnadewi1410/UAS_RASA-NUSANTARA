import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/user_model.dart';
import '../services/database_helper.dart';

class UserProvider with ChangeNotifier {
  final String _baseUrl =
      kIsWeb ? 'http://localhost:3000' : 'http://10.0.2.2:3000';
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  User? _currentUser;
  bool _isLoading = false;
  String? _error;

  // Getters
  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _currentUser != null;

  // ContentProvider-like methods for user data access
  Future<bool> login(String username, String password) async {
    _setLoading(true);
    _clearError();

    try {
      // Try local database first
      User? localUser = await _databaseHelper.getUser(
        username: username,
        password: password,
      );

      // If local user exists, use it
      if (localUser != null) {
        _currentUser = localUser;
        notifyListeners();
      }

      // Then try server authentication
      final response = await http.post(
        Uri.parse('$_baseUrl/api/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _currentUser = User(
          id: data['userId'],
          username: username,
          password: password,
        );

        // Update local database
        await _updateLocalUser(_currentUser!);
        notifyListeners();
        return true;
      } else {
        print('Login failed. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        final message = jsonDecode(response.body)['message'];
        _setError(message ?? 'Login gagal');
        return false;
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> register(String username, String password) async {
    _setLoading(true);
    _clearError();

    try {
      // Create user in local database first
      User newUser = User(username: username, password: password);

      int localId = await _databaseHelper.addUser(newUser);

      // Then sync with server
      final response = await http.post(
        Uri.parse('$_baseUrl/api/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': username, 'password': password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _currentUser = User(
          id: data['userId'],
          username: username,
          password: password,
        );

        notifyListeners();
        return true;
      } else {
        print('Registration failed. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        final message = jsonDecode(response.body)['message'];
        _setError(message ?? 'Registrasi gagal');
        return false;
      }
    } catch (e) {
      if (e.toString().contains('Username sudah ada')) {
        _setError('Username ini sudah terdaftar. Coba username lain.');
      } else {
        _setError('Tidak dapat terhubung ke server atau terjadi error lokal.');
      }
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> logout() async {
    _currentUser = null;
    _clearError();
    notifyListeners();
  }

  Future<void> loadUserFromLocal(int userId) async {
    try {
      // This would need to be implemented in DatabaseHelper
      // For now, we'll just set a basic user object
      _currentUser = User(
        id: userId,
        username: 'User', // This should be loaded from local storage
        password: '',
      );
      notifyListeners();
    } catch (e) {
      _setError('Gagal memuat data user');
    }
  }

  // Helper methods
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
  }

  Future<void> _updateLocalUser(User user) async {
    try {
      // Add or update user in local database
      await _databaseHelper.addUser(user);
    } catch (e) {
      // User might already exist, that's okay
    }
  }

  // Clear all data (useful for logout)
  void clearData() {
    _currentUser = null;
    _error = null;
    notifyListeners();
  }
}
