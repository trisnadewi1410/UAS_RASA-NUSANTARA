import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/recipe_model.dart';
import '../services/database_helper.dart';

class RecipeProvider with ChangeNotifier {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  List<Recipe> _recipes = [];
  List<Recipe> _allRecipes = [];
  bool _isLoading = false;
  String? _error;

  // Getters
  List<Recipe> get recipes => _recipes;
  List<Recipe> get allRecipes => _allRecipes;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // ContentProvider-like methods for data access
  Future<void> loadUserRecipes(int userId) async {
    _setLoading(true);
    _clearError();

    try {
      // Try to get from local database first
      List<Recipe> localRecipes = await _databaseHelper.getRecipes(userId);

      // If local data exists, use it
      if (localRecipes.isNotEmpty) {
        _recipes = localRecipes;
        notifyListeners();
      }

      // Then try to sync with server
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/recipes?userId=$userId'),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        _recipes = data.map((e) => Recipe.fromMap(e)).toList();

        // Update local database
        await _updateLocalRecipes(_recipes, userId);
      } else {
        _setError('Gagal mengambil resep dari server');
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
    } finally {
      _setLoading(false);
    }
  }

  Future<void> loadAllRecipes() async {
    _setLoading(true);
    _clearError();

    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/all-recipes'),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        _allRecipes = data.map((e) => Recipe.fromMap(e)).toList();
      } else {
        _setError('Gagal mengambil semua resep');
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> addRecipe(Recipe recipe) async {
    _setLoading(true);
    _clearError();

    try {
      // Add to local database first
      int localId = await _databaseHelper.addRecipe(recipe);

      // Then sync with server
      final response = await http.post(
        Uri.parse('http://localhost:3000/api/recipes'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(recipe.toMap()),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        Recipe newRecipe = Recipe(
          id: data['id'],
          title: recipe.title,
          description: recipe.description,
          ingredients: recipe.ingredients,
          steps: recipe.steps,
          imagePath: recipe.imagePath,
          userId: recipe.userId,
        );

        _recipes.add(newRecipe);
        notifyListeners();
        return true;
      } else {
        _setError('Gagal menambah resep');
        return false;
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> updateRecipe(Recipe recipe) async {
    _setLoading(true);
    _clearError();

    try {
      // Update local database first
      await _databaseHelper.updateRecipe(recipe);

      // Then sync with server
      final response = await http.put(
        Uri.parse('http://localhost:3000/api/recipes/${recipe.id}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(recipe.toMap()),
      );

      if (response.statusCode == 200) {
        final index = _recipes.indexWhere((r) => r.id == recipe.id);
        if (index != -1) {
          _recipes[index] = recipe;
          notifyListeners();
        }
        return true;
      } else {
        _setError('Gagal mengupdate resep');
        return false;
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> deleteRecipe(int recipeId) async {
    _setLoading(true);
    _clearError();

    try {
      // Delete from local database first
      await _databaseHelper.deleteRecipe(recipeId);

      // Then sync with server
      final response = await http.delete(
        Uri.parse('http://localhost:3000/api/recipes/$recipeId'),
      );

      if (response.statusCode == 200) {
        _recipes.removeWhere((recipe) => recipe.id == recipeId);
        notifyListeners();
        return true;
      } else {
        _setError('Gagal menghapus resep');
        return false;
      }
    } catch (e) {
      _setError('Tidak dapat terhubung ke server');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Helper methods
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
  }

  Future<void> _updateLocalRecipes(List<Recipe> recipes, int userId) async {
    // Clear existing recipes for this user
    for (Recipe recipe in recipes) {
      if (recipe.id != null) {
        await _databaseHelper.deleteRecipe(recipe.id!);
      }
    }

    // Add new recipes
    for (Recipe recipe in recipes) {
      await _databaseHelper.addRecipe(recipe);
    }
  }

  // Clear all data (useful for logout)
  void clearData() {
    _recipes.clear();
    _allRecipes.clear();
    _error = null;
    notifyListeners();
  }
}
