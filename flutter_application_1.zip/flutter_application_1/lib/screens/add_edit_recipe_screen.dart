import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/recipe_model.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:async';
import 'package:google_maps/google_maps.dart' as gmaps;
import 'dart:html' as html;
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart' show kIsWeb;

class AddEditRecipeScreen extends StatefulWidget {
  final Recipe? recipe;

  const AddEditRecipeScreen({super.key, this.recipe});

  @override
  _AddEditRecipeScreenState createState() => _AddEditRecipeScreenState();
}

class _AddEditRecipeScreenState extends State<AddEditRecipeScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _ingredientsController;
  late TextEditingController _stepsController;
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  String? _location;
  String? _address;
  gmaps.GMap? _gMap;
  gmaps.Marker? _marker;
  final _mapKey = GlobalKey();
  gmaps.LatLng? _selectedLatLng;
  StreamSubscription? _mapClickSub;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.recipe?.title);
    _descriptionController = TextEditingController(
      text: widget.recipe?.description,
    );
    _ingredientsController = TextEditingController(
      text: widget.recipe?.ingredients,
    );
    _stepsController = TextEditingController(text: widget.recipe?.steps);
    if (widget.recipe?.imagePath != null) {
      _imageFile = File(widget.recipe!.imagePath!);
    }
    // Register view factory for Google Maps Web
    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory('gmap-canvas', (int viewId) {
      final mapDiv =
          html.DivElement()
            ..id = 'gmap-canvas'
            ..style.width = '100%'
            ..style.height = '100%';
      return mapDiv;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initMap(_selectedLatLng);
    });
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _pickImageFromCamera() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return;
    }
    final position = await Geolocator.getCurrentPosition();
    setState(() {
      _location = '${position.latitude}, ${position.longitude}';
    });
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        setState(() {
          _address = [
            place.subAdministrativeArea,
            place.administrativeArea,
            place.country,
          ].where((e) => e != null && e.isNotEmpty).join(', ');
        });
      }
    } catch (e) {
      setState(() {
        _address = null;
      });
    }
  }

  Future<void> _saveRecipe() async {
    if (_formKey.currentState!.validate()) {
      final appProvider = Provider.of<AppProvider>(context, listen: false);
      final userProvider = appProvider.userProvider;
      final recipeProvider = appProvider.recipeProvider;

      if (userProvider.currentUser == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error: User not found. Please re-login.'),
          ),
        );
        return;
      }

      final recipe = Recipe(
        id: widget.recipe?.id,
        title: _titleController.text,
        description: _descriptionController.text,
        ingredients: _ingredientsController.text,
        steps: _stepsController.text,
        imagePath: _imageFile?.path,
        userId: userProvider.currentUser!.id!,
      );

      bool success;
      if (widget.recipe == null) {
        success = await recipeProvider.addRecipe(recipe);
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Resep berhasil ditambahkan!')),
          );
        }
      } else {
        success = await recipeProvider.updateRecipe(recipe);
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Resep berhasil diperbarui!')),
          );
        }
      }

      if (success && mounted) {
        Navigator.pop(context);
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(recipeProvider.error ?? 'Gagal menyimpan resep!'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _initMap([gmaps.LatLng? latLng]) async {
    await Future.delayed(Duration(milliseconds: 100));
    final mapDiv = html.document.getElementById('gmap-canvas');
    if (mapDiv == null) return;
    final center = latLng ?? gmaps.LatLng(-6.1751, 106.8650); // Default Jakarta
    final options =
        gmaps.MapOptions()
          ..zoom = 5
          ..center = center;
    _gMap = gmaps.GMap(mapDiv as html.HtmlElement, options);
    _marker = gmaps.Marker(
      gmaps.MarkerOptions()
        ..position = center
        ..map = _gMap,
    );
    _mapClickSub = _gMap!.onClick.listen((e) async {
      final lat = e.latLng?.lat ?? -6.1751;
      final lng = e.latLng?.lng ?? 106.8650;
      _marker!.position = gmaps.LatLng(lat, lng);
      _selectedLatLng = gmaps.LatLng(lat, lng);
      // Reverse geocoding
      List<Placemark> placemarks = await placemarkFromCoordinates(
        lat.toDouble(),
        lng.toDouble(),
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        setState(() {
          _address = [
            place.subAdministrativeArea,
            place.administrativeArea,
            place.country,
          ].where((e) => e != null && e.isNotEmpty).join(', ');
        });
      }
    });
  }

  Future<void> _onAddressChanged(String val) async {
    setState(() {
      _address = val;
    });
    if (val.isNotEmpty) {
      final geocodeResult = await gmaps.Geocoder().geocode(
        gmaps.GeocoderRequest()..address = val,
      );
      final results =
          geocodeResult.results?.whereType<gmaps.GeocoderResult>().toList() ??
          [];
      if (results.isNotEmpty) {
        final loc = results.first.geometry?.location;
        if (loc != null) {
          _selectedLatLng = gmaps.LatLng(
            loc.lat ?? -6.1751,
            loc.lng ?? 106.8650,
          );
          _marker?.position = gmaps.LatLng(
            loc.lat ?? -6.1751,
            loc.lng ?? 106.8650,
          );
          _gMap?.panTo(gmaps.LatLng(loc.lat ?? -6.1751, loc.lng ?? 106.8650));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.recipe == null ? 'Tambah Resep' : 'Edit Resep'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Consumer<AppProvider>(
                builder: (context, appProvider, _) {
                  final error = appProvider.recipeProvider.error;
                  if (error != null && error.isNotEmpty) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red[100],
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.red),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error, color: Colors.red),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              error,
                              style: const TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        height: 120,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey),
                        ),
                        child:
                            _imageFile != null
                                ? ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child:
                                      kIsWeb
                                          ? Image.network(
                                            _imageFile!.path,
                                            fit: BoxFit.contain,
                                            alignment: Alignment.center,
                                            width: double.infinity,
                                            height: 120,
                                          )
                                          : Image.file(
                                            _imageFile!,
                                            fit: BoxFit.contain,
                                            alignment: Alignment.center,
                                            width: double.infinity,
                                            height: 120,
                                          ),
                                )
                                : const Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.image,
                                        size: 40,
                                        color: Colors.grey,
                                      ),
                                      SizedBox(height: 8),
                                      Text('Pilih Gambar'),
                                    ],
                                  ),
                                ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Kolom Asal Masakan selalu tampil
              const SizedBox(height: 8),
              TextFormField(
                initialValue: _address ?? '',
                decoration: const InputDecoration(
                  labelText: 'Asal Masakan',
                  border: OutlineInputBorder(),
                ),
                onChanged: _onAddressChanged,
              ),
              const SizedBox(height: 12),
              Container(
                key: _mapKey,
                height: 250,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.brown),
                  borderRadius: BorderRadius.circular(12),
                ),
                child:
                    _gMap == null
                        ? const Center(child: Text('Peta gagal dimuat'))
                        : HtmlElementView(viewType: 'gmap-canvas'),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: _getCurrentLocation,
                icon: const Icon(Icons.location_on),
                label: const Text('Ambil Lokasi Sekarang'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Judul Resep',
                  border: OutlineInputBorder(),
                ),
                validator:
                    (value) =>
                        value!.isEmpty ? 'Judul tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator:
                    (value) =>
                        value!.isEmpty ? 'Deskripsi tidak boleh kosong' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _ingredientsController,
                decoration: const InputDecoration(
                  labelText: 'Bahan-bahan',
                  border: OutlineInputBorder(),
                  hintText: 'Masukkan bahan-bahan, pisahkan dengan koma',
                ),
                maxLines: 5,
                validator:
                    (value) =>
                        value!.isEmpty
                            ? 'Bahan-bahan tidak boleh kosong'
                            : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _stepsController,
                decoration: const InputDecoration(
                  labelText: 'Langkah-langkah',
                  border: OutlineInputBorder(),
                  hintText: 'Masukkan langkah-langkah memasak',
                ),
                maxLines: 8,
                validator:
                    (value) =>
                        value!.isEmpty
                            ? 'Langkah-langkah tidak boleh kosong'
                            : null,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _saveRecipe,
                icon: const Icon(Icons.save),
                label: const Text('Simpan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE07A5F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _ingredientsController.dispose();
    _stepsController.dispose();
    _mapClickSub?.cancel();
    super.dispose();
  }
}
