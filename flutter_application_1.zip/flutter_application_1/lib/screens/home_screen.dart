import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../models/recipe_model.dart';
import 'recipe_detail_screen.dart';
import 'all_recipes_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _loadRecipes();
  }

  Future<void> _loadRecipes() async {
    final appProvider = Provider.of<AppProvider>(context, listen: false);
    if (appProvider.userProvider.currentUser != null) {
      await appProvider.recipeProvider.loadUserRecipes(
        appProvider.userProvider.currentUser!.id!,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: ClipOval(
                  child: Image.asset(
                    'assets/logo/logo_resepkita.jpg',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            const Text(
              'ResepKita',
              style: TextStyle(
                color: Color(0xFFF5E9DA),
                fontWeight: FontWeight.bold,
                fontSize: 24,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF7B3F00),
        iconTheme: const IconThemeData(color: Color(0xFFF5E9DA)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFFF5E9DA)),
            onPressed: _loadRecipes,
          ),
        ],
      ),
      body: Consumer<AppProvider>(
        builder: (context, appProvider, child) {
          final recipeProvider = appProvider.recipeProvider;

          if (recipeProvider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (recipeProvider.error != null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    recipeProvider.error!,
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _loadRecipes,
                    child: const Text('Coba Lagi'),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.public),
                    label: const Text('Lihat Semua Resep'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE07A5F),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      textStyle: const TextStyle(fontSize: 18),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AllRecipesScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
              Expanded(
                child:
                    recipeProvider.recipes.isEmpty
                        ? const Center(
                          child: Text(
                            'Anda belum punya resep.\nTekan tombol + untuk menambah.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )
                        : ListView.builder(
                          padding: const EdgeInsets.all(8.0),
                          itemCount: recipeProvider.recipes.length,
                          itemBuilder: (context, index) {
                            final recipe = recipeProvider.recipes[index];
                            return Card(
                              elevation: 4,
                              margin: const EdgeInsets.symmetric(vertical: 8.0),
                              color: Color(0xFFF9F6F2),
                              child: ListTile(
                                contentPadding: const EdgeInsets.all(12.0),
                                leading: Hero(
                                  tag: 'recipeImage_${recipe.id}',
                                  child:
                                      recipe.imagePath != null &&
                                              recipe.imagePath!.isNotEmpty
                                          ? ClipRRect(
                                            borderRadius: BorderRadius.circular(
                                              8.0,
                                            ),
                                            child: Image.file(
                                              File(recipe.imagePath!),
                                              width: 60,
                                              height: 60,
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (
                                                    context,
                                                    error,
                                                    stackTrace,
                                                  ) => const Icon(
                                                    Icons.broken_image,
                                                    size: 60,
                                                  ),
                                            ),
                                          )
                                          : Container(
                                            width: 60,
                                            height: 60,
                                            decoration: BoxDecoration(
                                              color: Color(0xFFF5E9DA),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            child: const Icon(
                                              Icons.restaurant_menu,
                                              size: 30,
                                              color: Color(0xFF7B3F00),
                                            ),
                                          ),
                                ),
                                title: Text(
                                  recipe.title,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text(
                                  recipe.description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder:
                                          (context) => RecipeDetailScreen(
                                            recipe: recipe,
                                          ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
              ),
            ],
          );
        },
      ),
    );
  }
}
