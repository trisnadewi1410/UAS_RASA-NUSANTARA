import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/recipe_model.dart';
import 'package:flutter_application_1/screens/add_edit_recipe_screen.dart';

class RecipeDetailScreen extends StatelessWidget {
  final Recipe recipe;

  const RecipeDetailScreen({super.key, required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300.0,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                recipe.title,
                style: const TextStyle(
                  shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                ),
              ),
              background:
                  recipe.imagePath != null && recipe.imagePath!.isNotEmpty
                      ? Hero(
                        tag: 'recipeImage_${recipe.id}',
                        child: Image.file(
                          File(recipe.imagePath!),
                          fit: BoxFit.cover,
                        ),
                      )
                      : Container(
                        color: Colors.grey,
                        child: const Icon(
                          Icons.restaurant_menu,
                          size: 100,
                          color: Colors.white70,
                        ),
                      ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AddEditRecipeScreen(recipe: recipe),
                    ),
                  ).then((_) {
                    // Pop back to home screen after editing to force refresh
                    Navigator.pop(context);
                  });
                },
              ),
            ],
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      recipe.description,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Bahan-bahan',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const Divider(thickness: 1),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        '• ${recipe.ingredients.replaceAll(',', '\n• ')}',
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Langkah-langkah',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const Divider(thickness: 1),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(recipe.steps),
                    ),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
