import 'package:flutter/material.dart';
import 'edit_profile_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = false; // Dummy, belum terhubung ke theme
    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.person, color: Color(0xFF7B3F00)),
            title: const Text('Edit Profil'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const EditProfileScreen(),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.color_lens, color: Color(0xFF7B3F00)),
            title: const Text('Ganti Tema'),
            subtitle: const Text('Fitur coming soon!'),
            onTap: () {},
          ),
          SwitchListTile(
            secondary: const Icon(Icons.dark_mode, color: Color(0xFF7B3F00)),
            title: const Text('Mode Gelap'),
            value: isDarkMode,
            onChanged: (val) {
              // TODO: Implementasi mode gelap
            },
          ),
          ListTile(
            leading: const Icon(Icons.language, color: Color(0xFF7B3F00)),
            title: const Text('Bahasa'),
            subtitle: const Text('Fitur coming soon!'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.notifications, color: Color(0xFF7B3F00)),
            title: const Text('Notifikasi'),
            subtitle: const Text('Fitur coming soon!'),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.arrow_back),
            title: const Text('Kembali ke Profil'),
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
